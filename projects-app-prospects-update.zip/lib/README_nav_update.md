# Header / Navigation update

To add header links to **Dashboard**, **Projects**, **Prospects**, and **Search**, update your header/nav component (where you currently link to Projects/Search). Example JSX:

```tsx
import Link from "next/link";

export function AppHeader() {
  return (
    <header className="w-full border-b py-3 px-4 flex gap-3">
      <Link href="/dashboard" className="px-3 py-2 rounded-xl hover:bg-gray-100">Dashboard</Link>
      <Link href="/projects" className="px-3 py-2 rounded-xl hover:bg-gray-100">Projects</Link>
      <Link href="/prospects" className="px-3 py-2 rounded-xl hover:bg-gray-100">Prospects</Link>
      <Link href="/projects/search" className="px-3 py-2 rounded-xl hover:bg-gray-100">Search</Link>
    </header>
  );
}
```

If your app already has a shared header (e.g., in `app/layout.tsx`), insert the links there instead of creating a new header component.
```

This change will not affect the existing functionality; it only adds navigation links.