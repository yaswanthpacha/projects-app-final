export interface Prospect {
  id: number;
  prospect: string;
  ns_sales_rep?: string | null;
  zenardy_sc?: string | null;
  industry?: string | null;
  ns_solution_proposed?: string | null;
  zenardy_cost?: number | null;
  close_date?: string | null; // ISO date
  stage?: string | null;
  next_steps?: string | null;
  status?: "new" | "open" | "converted" | "dropped" | string | null;
  project_id?: number | null;
  created_at?: string | null;
  updated_at?: string | null;
}